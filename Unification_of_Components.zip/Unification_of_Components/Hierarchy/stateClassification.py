from nltk.corpus import wordnet as wn
import os

class stateHierarchy():

    def __init__(self):
        pass

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def classState(self):
        os.chdir('D:/PhD_Projects/Unification_of_Components/Hierarchy')
        files = open("StateClass.txt", "r")
        listEntity = []
        for f in files.readlines():
            entity = f.replace("\n", "").replace("_", " ").replace("-", " ").replace(" of ", " ").replace(" for ", " ").lower()

            listEntity.append(entity)
        files.close()

        f = open("D:/TopBraid/SoCoLA_ULO/ULO_New.ttl", "a")

        for e in listEntity:
            f.write(":" + str(e.capitalize().replace(" ", "_").replace("'s", "")) +
                    " rdfs:subClassOf :State; rdf:type owl:Class  .\n")


        f.close()

        return 1