import json
import os

class process():


    def __init__(self, objectN2, actionN2):
        self.objectN2 = objectN2
        self.actionN2 = actionN2


    def unify(self):


        for property in self.objectN2:
            hashHelp = {}
            for h in self.objectN2[property]:
                for pr in h:
                    if hashHelp.get(pr) == None:
                        hashHelp.setdefault(pr, []).append(h[pr])
                    else:
                        hashHelp[pr].append(h[pr])
            self.objectN2[property] = hashHelp

        for property in self.actionN2:
            hashHelp = {}
            for h in self.actionN2[property]:
                for pr in h:
                    if hashHelp.get(pr) == None:
                        hashHelp.setdefault(pr, []).append(h[pr])
                    else:
                        hashHelp[pr].append(h[pr])
            self.actionN2[property] = hashHelp

        return self.objectN2, self.actionN2

    def export(self, N1, N2, object, action):
        name = str(object) + str(action).capitalize() + ".json"
        hO = {}
        hA = {}
        h = {}
        hO['N1'] = N1[0]
        hO['N2'] = N2[0]
        hA['N1'] = N1[1]
        hA['N2'] = N2[1]

        h[str(object)] = hO
        h[str(action)] = hA

        os.chdir("D:/Phd_Projects/Unification_of_Components/subgraph")
        with open(str(name), 'w') as out:
            json.dump(h, out)

    def exportBigger(self, N1, N2, object, action, N):
        name = str(object) + str(action).capitalize() + ".json"
        hO = {}
        hA = {}
        h = {}
        hO['N1'] = N1[0]
        hO['N2'] = N2[0]
        hA['N1'] = N1[1]
        hA['N2'] = N2[1]

        k = 3
        for deep in N:
            t = 'N' + str(k)
            hO[t] = deep[0]
            hA[t] = deep[1]
            k += 1


        h[str(object)] = hO
        h[str(action)] = hA

        os.chdir("D:/Phd_Projects/Unification_of_Components/subgraph")
        with open(str(name), 'w') as out:
            json.dump(h, out)
