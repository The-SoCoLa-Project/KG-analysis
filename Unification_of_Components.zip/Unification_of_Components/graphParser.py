import json
from nltk.corpus import wordnet as wn
import os

class mainParser():

    def __init__(self, json, object, action):
        self.json = json
        self.object = object
        self.action = action

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final


    def common(self):
        obj = self.json[str(self.object)]
        action = self.json[str(self.action)]

        O = []
        for n in obj:
            for t in obj[n]:
                if str(t[1]) != str(self.object):
                    O = O + [t[1]]

        O = self.Remove(O)

        A = []
        for n in action:
            for t in action[n]:
                if str(t[1]) != str(self.action):
                    A = A + [t[1]]
        A = self.Remove(A)

        lenOb = len(O)
        lenA = len(A)
        co1 = list(set(O).intersection(A))
        lenC = len(co1)
        value = lenC/(lenA + lenOb)

        print("\nCommon nodes similarity: " + str(value))

        return co1, O, A, lenC, value


    def wup(self):

        try:
            syn1 = wn.synsets(self.object)[0]
            syn2 = wn.synsets(self.action)[0]
            wUp = syn1.wup_similarity(syn2)
            print("WUP similarity: " + str(wUp))
            return wUp
        except Exception:
            return 0


    def path(self, C):

        object = self.json[str(self.object)]
        action = self.json[str(self.action)]
        C = self.Remove(C)

        pathO = []
        for c in C:
            for n in object:
                for t in object[n]:
                    if c == t[1]:
                        pathO.append((t[0], c))
        pathO = self.Remove(pathO)

        pathA = []
        for c in C:
            for n in action:
                for t in action[n]:
                    if c == t[1]:
                        pathA.append((t[0], c))
        pathA = self.Remove(pathA)

        pO = []
        for o in pathO:
            for a in pathA:
                if o[1] == a[1]:
                    if isinstance(a[0], str) and isinstance(o[0], str):
                        t = [o[0]] + [a[0]]
                    elif isinstance(o[0], str):
                        t = [o[0]] + a[0]
                    elif isinstance(a[0], str):
                        t = o[0] + [a[0]]
                    else:
                        t = o[0] + a[0]
                    pO.append((t, o[1]))
        pO = self.Remove(pO)

        pA = []
        for a in pathA:
            for o in pathO:
                if a[1] == o[1]:
                    if isinstance(o[1], str) and isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                    elif isinstance(o[1], str):
                        t = a[0] + [o[0]]
                    elif isinstance(a[1], str):
                        t = [a[0]] + [o[0]]
                    else:
                        t = a[0] + o[0]
                    pA.append((t, a[1]))
        pA = self.Remove(pA)


        le = len(pO) + len(pA)

        lO = 0
        for n in object:
            lO = lO + len(object[n])

        lA = 0
        for n in action:
            lA = lA + len(action[n])

        lTotal = lO + lA

        valuePath = float(le/lTotal)
        print("There are " + str(len(pO) + len(pA)) + " common paths in total, which is a percentage of the"
                                                      " total paths " + str(valuePath))

        return pO, pA, valuePath, le



    def pathPattern(self, pO, pA, le, POS):

        pattern = []
        if POS == "OA":
            pattern = [("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 10418),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 2768),
             ("['/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 1627),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo']", 1627),
             ("['/r/RelatedTo', '/r/IsA', '/r/RelatedTo', '/r/IsA']", 1550),
             ("['/r/RelatedTo', '/r/RelatedTo','/r/HasProperty', '/r/RelatedTo']", 812),
             ("['/r/HasProperty', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 812),
             ("['/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo']", 657),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation']", 657),
             ("['/r/IsA', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 641),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/IsA', '/r/RelatedTo']", 641),
             ("['/r/RelatedTo', '/r/IsA', '/r/RelatedTo', '/r/IsA']", 616),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 610),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/UsedFor', '/r/RelatedTo']", 525),
             ("['/r/UsedFor', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 525),
             ("['/r/AtLocation', '/r/AtLocation', '/r/RelatedTo', '/r/AtLocation']", 508),
             ("['/r/RelatedTo', '/r/AtLocation', '/r/AtLocation', '/r/AtLocation']", 508),
             ("['/r/RelatedTo', '/r/RelatedTo', '/r/Synonym', '/r/RelatedTo']", 505),
             ("['/r/Synonym', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 505),
             ("['/r/Synonym', '/r/RelatedTo', '/r/RelatedTo', '/r/Synonym']", 550),
             ("['/r/Synonym', '/r/RelatedTo', '/r/UsedFor', '/r/Synonym']", 550),
             ("['/r/Synonym', '/r/UsedFor', '/r/RelatedTo', '/r/Synonym']", 550),
             ("['/r/Synonym', '/r/UsedFor', '/r/UsedFor', '/r/Synonym']", 540),
             ("['/r/Synonym', '/r/RelatedTo', '/r/RelatedTo', '/r/Synonym']", 540),
             ("['/r/Synonym', '/r/RelatedTo', '/r/LocatedAt', '/r/Synonym']", 530),
             ("['/r/Synonym', '/r/LocatedAt', '/r/RelatedTo', '/r/Synonym']", 530),
             ("['/r/Synonym', '/r/LocatedAt', '/r/LocatedAt', '/r/Synonym']", 520)]
        elif POS == "S0" or POS == "S1":
            pattern = [("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 10418),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 2768),
                       ("['/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 1627),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo']", 1627),
                       ("['/r/RelatedTo', '/r/IsA', '/r/RelatedTo', '/r/IsA']", 1550),
                       ("['/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo', '/r/AtLocation']", 1358),
                       ("['/r/UsedFor', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 968),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/UsedFor', '/r/RelatedTo']", 968),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/IsA', '/r/RelatedTo']", 903),
                       ("['/r/IsA', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 903),
                       ("['/r/RelatedTo', '/r/UsedFor', '/r/RelatedTo', '/r/UsedFor']", 820),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation']", 713),
                       ("['/r/RelatedTo', '/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo']", 713),
                       ("['/r/AtLocation', '/r/AtLocation', '/r/RelatedTo', '/r/RelatedTo']", 634),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/AtLocation', '/r/AtLocation']", 634),
                       ("['/r/RelatedTo', '/r/RelatedTo', '/r/FormOf', '/r/RelatedTo']", 589),
                       ("['/r/FormOf', '/r/RelatedTo', '/r/RelatedTo', '/r/RelatedTo']", 589),
                       ("['/r/AtLocation', '/r/AtLocation', '/r/RelatedTo', '/r/AtLocation']", 588),
                       ("['/r/RelatedTo', '/r/AtLocation', '/r/AtLocation', '/r/AtLocation']", 588),
                       ("['/r/Synonym', '/r/RelatedTo', '/r/RelatedTo', '/r/Synonym']", 550),
                       ("['/r/Synonym', '/r/RelatedTo', '/r/UsedFor', '/r/Synonym']", 550),
                       ("['/r/Synonym', '/r/UsedFor', '/r/RelatedTo', '/r/Synonym']", 550),
                       ("['/r/Synonym', '/r/UsedFor', '/r/UsedFor', '/r/Synonym']", 540),
                       ("['/r/Synonym', '/r/RelatedTo', '/r/RelatedTo', '/r/Synonym']", 540),
                       ("['/r/Synonym', '/r/RelatedTo', '/r/LocatedAt', '/r/Synonym']", 530),
                       ("['/r/Synonym', '/r/LocatedAt', '/r/RelatedTo', '/r/Synonym']", 530),
                       ("['/r/Synonym', '/r/LocatedAt', '/r/LocatedAt', '/r/Synonym']", 520)]

        PATH = pO + pA
        syn1 = wn.synsets(self.object)[0]
        syn2 = wn.synsets(self.action)[0]
        hashPattern = {}##hash with key the path pattern and elements list of tuples first element wup value,
                        ##and second list of entities that gave the wup value

        counter = 0
        for p in pattern:
            for path in PATH:
                if str(p[0]) == str(path[0]):
                    counter = counter + 1
                    try:
                        syn3 = wn.synsets(path[1])[0]
                        wup0 = syn1.wup_similarity(syn3)
                        wup1 = syn2.wup_similarity(syn3)
                        if wup0 == None:
                            wup0 = 0.1
                        if wup1 == None:
                            wup1 = 0.1
                        wup = (wup0 + wup1)/2
                    except Exception:
                        wup = 0
                    if hashPattern.get(p[0]) == None:
                        hashPattern.setdefault(p[0], []).append((wup, [self.object, path[1], self.action]))
                    else:
                        hashPattern[p[0]].append((wup, [self.object, path[1], self.action]))


        maxWup = []
        for prp in hashPattern:
            c = 0
            for e in hashPattern[prp]:
                c = c + e[0]
            try:
                maxWup.append((prp, c/len(hashPattern[prp])))
            except Exception:
                maxWup.append((prp, c/len(hashPattern[prp])))

        maxWup = sorted(maxWup, key=lambda x: x[1], reverse=True)

        valuePattern = maxWup[0][1]

        print("Path pattern value: " + str(valuePattern))
        return valuePattern, POS


    def infer(self, valueCommon, valueWUP, valuePath, valuePattern, POS):

        if valueWUP == None:
            valueWUP = 0.01##if none wordnet could not find one of the two words
            ##but is two strict to consider them zero, we use labels from the englidh language
            ##which were not found in a database

        listWeight = [valueWUP, valuePath, valueCommon, valuePattern]
        listWeight = sorted(listWeight, reverse=True)
        weight = 2*listWeight[0] + 1.5*listWeight[1] + 1.5*listWeight[2] + listWeight[3]
        weight = weight/4
        print("\n" + str(weight))
        helpWeight = valueWUP + valueCommon + valuePath

        if weight > 0.2:
            print("\nThe two graphs ARE related adequately")
            os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
            f = open("objPS.txt", "a")
            help = str(self.action) + ", " + str(self.object) + ", " + str(POS)
            f.write(help + "\n")
            f.close()
        else:
            if helpWeight > 0.16:
                print("\nThe two graphs ARE related adequately")
                os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
                f = open("objPS.txt", "a")
                help = str(self.action) + ", " + str(self.object) + ", " + str(POS)
                f.write(help + "\n")
                f.close()
            else:
                if valueWUP != 0.01:
                    print("\nThe two graphs ARE related adequately")
                    os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
                    f = open("objPS.txt", "a")
                    help = str(self.action) + ", " + str(self.object) + ", " + str(POS)
                    f.write(help + "\n")
                    f.close()
                else:
                    print("\nThe two graphs are NOT adequately related")

        os.chdir("D:/PhD_Projects/Unification_of_Components/reasonerInfo")
        f = open("pairMetric.txt", "a")
        help = str(self.object) + "-" + str(self.action) + " " + str(weight) + "\n"
        f.write(help)
        f.close()