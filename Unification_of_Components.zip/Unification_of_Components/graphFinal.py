import os, json
from os import listdir
from os.path import isfile, join
from context import *
from graphParser import *
from visionInput import *

def findJson(obj, action):
    fileObj = str(obj) + ".json"
    fileAction = str(action) + ".json"

    os.chdir("D:/Phd_Projects/Unification_of_Components/subgraph")
    with open(str(fileObj), 'r') as out:
        jObj = json.loads(out.read())
        O = jObj[str(obj)]

    with open(str(fileAction), 'r') as out:
        jAction = json.loads(out.read())
        A = jAction[str(action)]

    hashFinal = {}
    hashFinal[str(obj)] = O
    hashFinal[str(action)] = A

    return hashFinal


def Remove(duplicate):
    final = []
    for num in duplicate:
        if num not in final:
            final.append(num)
    return final


def parserJson(jsonFile):

    l = list(jsonFile.keys())
    obj = jsonFile[str(l[0])]
    action = jsonFile[str(l[1])]
    oPath = {}
    aPath = {}
    Obj1 = []


    for property in obj['N1']:
        for e in obj['N1'][property]:
            if e != []:
                Obj1.append(([property], e))

    Act1 = []
    for property in action['N1']:
        for e in action['N1'][property]:
            if e != []:
                Act1.append(([property, e]))

    obj.pop('N1')
    action.pop('N1')
    oPath['N1'] = Obj1
    aPath['N1'] = Act1

    Obj2 = []
    for property in obj['N2']:
        for p in obj['N2'][property]:
            try:
                for e in obj['N2'][property][p]:
                    if e != []:
                        Obj2.append(([property, p], e))
            except Exception:
                    continue
    Act2 = []
    for property in action['N2']:
        for p in action['N2'][property]:
            try:
                for e in action['N2'][property][p]:
                    if e != []:
                        Act2.append(([property, p], e))
            except Exception:
                    continue
    obj.pop('N2')
    action.pop('N2')
    oPath['N2'] = Obj2
    aPath['N2'] = Act2


    if len(obj) > 0:
        Obj3 = []
        for n in obj:
            for property in obj[n]:
                for e in obj[n][property]:
                    if e[0] != []:
                        Obj3.append((e[1], e[0]))
            Obj3 = Remove(Obj3)
            oPath[str(n)] = Obj3

        Act3 = []
        for n in action:
            for property in action[n]:
                for e in action[n][property]:
                    if e[0] != []:
                        Act3.append((e[1], e[0]))
            Act3 = Remove(Act3)
            aPath[str(n)] = Act3

    hashFinal = {}
    hashFinal[str(l[0])] = oPath
    hashFinal[str(l[1])] = aPath
    return hashFinal

def findPrp(jsonFile, pair):

    if pair == "OA":
        prpList = [('/r/RelatedTo', 2), ('/r/AtLocation', 2), ('/r/FormOf', 2), ('/r/IsA', 2), ('/r/Synonym', 2),
                   ('/r/UsedFor', 2), ('/r/PartOf', 2), ('/r/CapableOf', 2), ('/r/SimilarTo', 1), ('/r/HasA', 1),
                   ('/r/HasProperty', 1), ('/r/ReceivesAction', 1), ('/r/MadeOf', 1), ('/r/CreatedBy', 1),
                   ('/r/LocatedNear', 1), ('/r/LocatedAt', 1)]
    elif pair == "S0" or pair == "S1":
        prpList = [('/r/RelatedTo', 2), ('/r/AtLocation', 2), ('/r/FormOf', 2), ('/r/IsA', 2), ('/r/Synonym', 2),
                   ('/r/UsedFor', 2), ('/r/PartOf', 2), ('/r/CapableOf', 2), ('/r/SimilarTo', 1),
                   ('/r/HasProperty', 1), ('/r/ReceivesAction', 1), ('/r/HasA', 1), ('/r/MadeOf', 1),
                   ('/r/CreatedBy', 1), ('/r/LocatedNear', 1), ('/r/LocatedAt', 1)]
    else:
        print("Sorry I cannot find the context")
        exit()

    k = list(jsonFile.keys())
    obj = jsonFile[str(k[0])]
    action = jsonFile[str(k[1])]

    pathO = {}
    for n in obj:
        pathObj = []
        for l in obj[n]:
            if isinstance(l[0], str):
                pathObj.append(l)
            else:
                flag = 0
                for p in l[0]:
                    val = len(l[0]) - l[0][::-1].index(p)
                    for prp in prpList:
                        if p == prp[0]:
                            if int(val) <= prp[1]:
                                flag = 0
                            else:
                                flag = 1
                                break
                if flag == 0:
                    pathObj.append(l)
        pathO[n] = pathObj

    pathA = {}
    for n in action:
        pathAction = []
        for l in action[n]:
            if isinstance(l, str):
                pathAction.append(l)
            else:
                flag = 0
                for p in l[0]:
                    val = len(l[0]) - l[0][::-1].index(p)
                    for prp in prpList:
                        if p == prp[0]:
                            if int(val) <= prp[1]:
                                flag = 0
                            else:
                                flag = 1
                                break
                if flag == 0:
                    pathAction.append(l)
        pathA[n] = pathAction

    hashFinal = {}
    hashFinal[str(k[0])] = pathO
    hashFinal[str(k[1])] = pathA

    return hashFinal



if __name__=="__main__":

    f = open("vision.txt", "r")
    for line in f.readlines():
        line = line.replace("\n", "").replace("[", "").replace("]", "").split(", ")
        os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
        t = open("objPS.txt", "a")
        help = str(line[2].split(" ")[0]) + ", " + str(line[1].split(" ")[0]) + "-" + str(line[4].split(" ")[0]) + ", SA"
        t.write(help + "\n")
        t.close()
        os.chdir("D:/PhD_Projects/Unification_of_Components")
        v = vision(line)
        pair = v.parseVision()

        for p in pair:
            jsonFile = findJson(p[0], p[1])

            parsed = parserJson(jsonFile)
            preFinal = findPrp(parsed, p[2])
            cont = cOn(preFinal, p[0], p[1])
            hashFinal = cont.findHypernyms()
            nameFinal = cont.export(hashFinal)
            print("...graph created!")

            parser = mainParser(hashFinal, p[0], p[1])
            C, objectList, actionList, lenC, valueCommon = parser.common()

            valueWUP = wupSimilarity = parser.wup()
            pO, pA, valuePath, lTotal = parser.path(C)

            valuePattern, p[2] = parser.pathPattern(pO, pA, lTotal, p[2])
            parser.infer(valueCommon, valueWUP, valuePath, valuePattern, p[2])

    os.chdir("D:/PhD_Projects/Unification_of_Components/kgInfo")
    exec(open("Main_Info.py").read())
    f = open("objPS.txt", "w")
    f.write("")
    f.close()