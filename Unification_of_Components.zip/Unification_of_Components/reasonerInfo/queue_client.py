import zmq
import sys
import random
import time
import base64, cv2
from reasonerMain import *
import numpy as np


ip=sys.argv[1]
port=sys.argv[2]

if port==None:
    port = "5559"

print(ip)
print(port)

print("Connecting to server...")

#  Do 10 requests, waiting each time for a response


if port=="5559":
    camera = cv2.VideoCapture(0)  # init the camera
    context = zmq.Context(1)
    socket = context.socket(zmq.REQ)
    socket.connect ("tcp://%s:%s" %(ip, port))
    client_id = 3

#id_dict=["controller"



    while(True):
        try:
           
            grabbed, frame = camera.read()  # grab the current frame
            frame = cv2.resize(frame, (640, 480))  # resize the frame
            encoded, buffer = cv2.imencode('.jpg', frame)
            jpg_as_text = base64.b64encode(buffer)
            socket.send(jpg_as_text)
           # print(111) 
            message = socket.recv()
            print("Received reply " +str(client_id)+ "[", message, "]")


        except KeyboardInterrupt:
            camera.release()
            cv2.destroyAllWindows()
            break

elif  port=="5557":
    print("using port %s."%port)
    context = zmq.Context()
    socket = context.socket(zmq.REP)
    socket.bind("tcp://*:%s" % port)
    client_id = 3 
    while(True):
        try:

           # msg = socket.recv()
           # print(msg)
            qu = reasonerNew()
            qu.start()

           # file_res=open('results.txt','r')
            #Lines = file_res.readlines()
            #for line in Lines:

            jsonInitMessage = {
            'Sender': "KB",
            'Source': "-",
            'Component': "-",
            'SessionId': "-",
            'Message': "Hello",
        }


            message = str(socket.recv_json(), "utf-8")
            print("Received request: ", message)
            time.sleep(1)
            socket.send_json(jsonInitMessage)
        except KeyboardInterrupt:
            camera.release()
            cv2.destroyAllWindows()
            break
   
  
