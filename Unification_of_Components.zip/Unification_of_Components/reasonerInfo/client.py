import zmq
import sys
import random
import time
import base64
from reasonerMain2 import *
import numpy as np

ip = sys.argv[1]
port = sys.argv[2]

if port == None:
    port = "5559"

print(ip)
print(port)

print("Connecting to server...")

jsonmsgTemplate = {
    'Sender': "KB",
    'Source': "KB",
    'Component': "-",
    'SessionId': "-",
    'Message': "",
}

print("using port %s." % port)
context = zmq.Context()
context = zmq.Context()
socket = context.socket(zmq.PULL)
socket.connect("tcp://%s:%s" % (ip, port))

socket2 = context.socket(zmq.PUSH)
socket2.bind("tcp://*:%s" % (str(int(port) + 10)))

qu = reasonerNew()

# file_res=open('results.txt','r')
# Lines = file_res.readlines()
# for line in Lines:
while (True):
    try:

        # msg = socket.recv()
        # print(msg)

        # file_res=open('results.txt','r')
        # Lines = file_res.readlines()
        # for line in Lines:

        message = socket.recv_json()
        print("Received request: ", message)
        qu.start(message)
        iid = message['SessionId']

        result_json = json.load(open('messageResult/message%s.json' % iid, 'r'))
        list_result = []

        for ent in result_json:

            curr_dict = (result_json[ent])

            action_state = curr_dict["State"]
            list_result.append([ent, action_state])
            if ('Record' in message['Message']):
                action_list = curr_dict["Action"]
                list_result.append([ent, action_list])

        jsonmsgTemplate['SessionId'] = iid
        jsonmsgTemplate['Message'] = list_result
        socket2.send_json(jsonmsgTemplate)
    except KeyboardInterrupt:
        camera.release()
        cv2.destroyAllWindows()
        break

