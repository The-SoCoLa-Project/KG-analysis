import zmq,json
import random
import sys
import time
import base64

port = sys.argv[1]

context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:%s" % port)

while True:
    #  Wait for next request from server

    var = input("Please enter something: ")
    message = str(socket.recv(), "utf-8")
    print("Received request: ", message)
    time.sleep(1)
    jsonInitMessage= {
        'Sender': "Controller",
        'Source': "%s"%port,
        'Component': "-",
        'SessionId': "-",
        'Message': "Hello",
    }
    #msg_json = json.dumps(msgDict)
    socket.send_json(jsonInitMessage)