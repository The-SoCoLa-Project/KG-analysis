from query import *
import rdflib
import json


#class reasonerNew:

#   def __init__(self):
#        pass

#   def start(self):
if __name__=="__main__":

        with open('input.json') as json_file:
            data = json.load(json_file)


        listObject = []
        for d in data['Message']:
            listObject.append(d[0])

        id = data['SessionId']

        listJson = []
        for l in listObject:
            label = l.replace("\n", "").split(" ")
            #choice = str(label[0])

            filename = "ULO_New.ttl"
            g = rdflib.Graph()
            graph = g.parse(filename, format="ttl")
            query = mainQuery(str(l).capitalize(), graph)
            classLabel, entity = query.isA()
            prp, state = query.hasProperty()
            #final = query.connect(prp, state)
            #flagExport = query.export(label, final)



            braker = "=========================================================================Demo SoCoLA=========" \
                     "======================================================================"
            print(braker)
            listJson.append((l, [prp, state]))

        flagExport = query.exportJson(id, listJson)
