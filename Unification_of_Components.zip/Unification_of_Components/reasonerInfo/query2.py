import json, os


class mainQuery:

    def __init__(self, label, graph):
        self.label = label
        self.graph = graph



    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def isA(self):
        q = """
            SELECT DISTINCT ?class ?mainClass WHERE{
                    :""" + str(self.label) + """ rdfs:subClassOf ?class .
                    ?class rdfs:subClassOf ?mainClass .
            }
        """
        qr = self.graph.query(q)
        objectClass = []
        for que in qr:
            for c in que:
                c = str(c).split("#")[1].replace("')", "")
                if c != 'SpatialThing':
                    c = "isTypeOf(" + str(self.label) + ", " + str(c) + ")"
                    objectClass.append(c)

        entity = "entity(" + str(self.label) + ")"
        objectClass = self.Remove(objectClass)

        e = "\nThe entity: " + str(entity)
        cl = "\nThe classes of the " + str(self.label) + ": " + str(objectClass)
        print(e)
        print(cl)


        return objectClass, entity

    def hasProperty(self):
        q = """SELECT DISTINCT ?property ?value WHERE{
                {:""" + str(self.label) + """ ?property ?value}
                UNION{?value ?property :""" + str(self.label) + """}
                }
                """
        qr = self.graph.query(q)
        desiredProperty = ['isInState', 'wasInstate']
        prp = []
        state = []
        f = open("pairMetric.txt", "r")
        metric = []
        for line in f.readlines():
            line = line.replace("\n", "")
            metric.append(line)
        f.close()

        for que in qr:
            property = que[0].split("#")[1].replace("')", "")
            value = que[1].split("#")[1].replace("')", "")
            helpValue = str(self.label) + "-" + str(value)
            if property == "performedBy":
                hasProperty = [str(value), str(property), str(self.label)]
                metricValue = 0
                for m in metric:
                    if helpValue.lower() in m:
                        metricValue = m.split(" ")[1]
                hasProperty = hasProperty + [metricValue]
                prp.append(hasProperty)
            if property in desiredProperty:
                hasState = [str(self.label), str(property), str(value)]
                metricValue = 0
                for m in metric:
                    if helpValue.lower() in m:
                        metricValue = m.split(" ")[1]
                hasState = hasState + [metricValue]
                state.append(hasState)



        prp = self.Remove(prp)
        state = self.Remove(state)

        prpFinal = []
        for p in prp:
            prpFinal = [[p[0], p[2], p[3]]] + prpFinal##more elegant

        stateFinal = []
        for s in state:
            stateFinal = [[s[0], s[2], s[3]]] + stateFinal##more elegant

        prpFinal = self.Remove(prpFinal)
        stateFinal = self.Remove(stateFinal)

        pr = "\nList of actions for " + str(self.label) + ": " + str(prpFinal)
        s = "\nList of states for " + str(self.label) + ": " + str(stateFinal)

        print(pr)
        print(s)

        return prp, state


    def connect(self, prp, state):##connect states to actions note that the states returned may not be in the correct order
                                  ##having the corrext order would require other architecture to the ontology at instance level

        final = []
        for action in prp:
            q = """SELECT DISTINCT ?value WHERE{
                    :""" + str(action[0]) + """ :relatedTo ?value}
                    """
            qr = self.graph.query(q)
            actionState = []
            for que in qr:
                st = que[0].split("#")[1].replace("')", "")
                actionState.append(st)
            actionState = self.Remove(actionState)


            finalState = []
            for s in actionState:
                for st in state:
                    if s == st[2]:
                        finalState.append([action[2], st[2], st[3]])
            finalState = self.Remove(finalState)
            finalState = [[action[0], action[2], action[3]]] + finalState
            final.append(finalState)

        return final


    def export(self, label, final):

        if len(label) > 1:
            new = []
            for f in final:
                if f[0][0] == label[1].capitalize():
                    new.append(f)
            e = "\nThe actions connected to states for " + str(self.label) + ": " + str(new)
            print(e)
        else:
            e = "\nThe actions connected to states for " + str(self.label) + ": " + str(final)
            print(e)


        return 1


    def exportJson(self, id, actionState):
        hashObject = {}
        for t in actionState:
            hashHelp = {}
            listState = []
            listAction = []
            for i in t[1][0]:
                listAction.append((i[0], i[3]))
            for i in t[1][1]:
                listState.append((i[2], i[3]))

            listAction = self.Remove(listAction)
            listState = self.Remove(listState)
            hashHelp['Action'] = listAction
            hashHelp['State'] = listState
            hashObject[str(t[0])] = hashHelp

       # hashObject['MessageId'] = str(id)
        name = "message" + str(id) + ".json"
        os.chdir("./messageResult")
        with open(str(name), 'w') as out:
            json.dump(hashObject, out)

        os.chdir("./..")


        return 1