from kgInfo.objPurposeState import *


if __name__=="__main__":
    ps = objPS()
    actionFlag = ps.performRelation()
    stateFlag = ps.stateRelation()
    actStateFlag = ps.stateAction() ##remove if we want this state