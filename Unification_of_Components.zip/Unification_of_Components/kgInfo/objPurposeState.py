

class objPS():

    def __init__(self):
        pass

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def performRelation(self):

        f = open("objPS.txt", "r")
        listPurpose = []
        for line in f.readlines():
            listPurpose.append(line.replace("\n", "").split(", "))
        f.close()

        listPurpose = self.Remove(listPurpose)
        g = open("D:/PhD_Projects/Unification_of_Components/reasonerInfo/ULO_New.ttl", "a")
        help = ""
        for purpose in listPurpose:
            if purpose[2] == "OA":
                help = ":" + str(purpose[0]).capitalize() + " :performedBy :" + str(purpose[1]).capitalize() + ".\n "
                g.write(help)
        g.close()

        return 1

    def stateRelation(self):

        f = open("objPS.txt", "r")
        listState = []
        for line in f.readlines():
            listState.append(line.replace("\n", "").split(", "))
        f.close()

        listState = self.Remove(listState)
        g = open("D:/PhD_Projects/Unification_of_Components/reasonerInfo/ULO_New.ttl", "a")
        for state in listState:
            if state[2] == "S0":
                help = ":" + str(state[1]).capitalize() + " :wasInstate :" + str(state[0]).capitalize() + ".\n"
                g.write(help)

        for state in listState:
            if state[2] == "S1":
                help = ":" + str(state[1].capitalize()) + " :isInState :" + str(state[0]).capitalize() + ".\n"
                g.write(help)


        g.close()
        return 1

    def stateAction(self):

        f = open("objPS.txt", "r")
        listPurpose = []
        for line in f.readlines():
            listPurpose.append(line.replace("\n", "").split(", "))
        f.close()

        listPurpose = self.Remove(listPurpose)
        g = open("D:/PhD_Projects/Unification_of_Components/reasonerInfo/ULO_New.ttl", "a")
        helpPurspose = []
        for purpose in listPurpose:
            if purpose[2] == "SA":
                state = purpose[1].split("-")
                state.sort()
                helpPurspose.append((purpose[0], state))

        helpPurspose = self.Remove(helpPurspose)
        help0 = ""
        help1 = ""
        for purpose in helpPurspose:
            help0 = ":" + str(purpose[0]).capitalize() + " :relatedTo :" + str(purpose[1][0]).capitalize() + ".\n "
            help1 = ":" + str(purpose[0]).capitalize() + " :relatedTo :" + str(purpose[1][1]).capitalize() + ".\n "
            g.write(help0 + help1)
        g.close()

        return 1