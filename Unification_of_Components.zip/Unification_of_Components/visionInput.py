import os, json
from os import listdir


class vision():


    def __init__(self, line):
        self.line = line

    def openJson(self):
        onlyfiles = [f for f in listdir("D:/PhD_Projects/Unification_of_Components/subgraphContext")]

        return onlyfiles

    def parseVision(self):
        obj = self.line[0].split(" ")[0]
        state0 = self.line[1].split(" ")[0]
        state1 = self.line[4].split(" ")[0]


        action = self.line[2].split(" ")[0]
        pair = [[obj, state0, "S0"], [obj, action, "OA"], [obj, state1, "S1"]]

        onlyfiles = self.openJson()

        listPair = []
        for p in pair:
            help = str(p[0]) + str(p[1].capitalize()) + "Context.json"
            if help in onlyfiles:
                pass
            else:
                listPair.append(p)

        return listPair

